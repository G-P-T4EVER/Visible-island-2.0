#import "VIIslandView.h"
#import "VIMediaView.h"
#import "VIPrefs.h"

static const CGFloat kVITouchSlop        = 6.0;
static const CGFloat kVIExpandWidthBoost = 84.0;
static const CGFloat kVIExpandHeightBoost = 14.0;

#pragma mark - Spring helper

// One tuned spring for every module transition. CASpringAnimation is used
// directly (not UIViewPropertyAnimator) because the modules are driven by
// explicit layer geometry, and because SpringBoard's own UIView animation
// context can be mid-transaction when a screen-state change arrives.
static CASpringAnimation *VISpring(NSString *keyPath, id from, id to) {
    CASpringAnimation *spring = [CASpringAnimation animationWithKeyPath:keyPath];
    spring.mass               = 0.85;
    spring.stiffness          = 320.0;
    spring.damping            = 26.0;
    spring.initialVelocity    = 0.0;
    spring.fromValue          = from;
    spring.toValue            = to;
    spring.duration           = spring.settlingDuration;
    spring.timingFunction     = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    spring.removedOnCompletion = YES;
    spring.fillMode           = kCAFillModeRemoved;
    return spring;
}

static inline CGFloat VIPixelAlign(CGFloat value) {
    CGFloat scale = UIScreen.mainScreen.scale ?: 2.0;
    return round(value * scale) / scale;
}

#pragma mark - VIIslandModuleView

@implementation VIIslandModuleView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = UIColor.blackColor;
        self.opaque          = NO;
        self.clipsToBounds   = YES;

        CALayer *layer = self.layer;
        layer.masksToBounds       = YES;              // required for media clipping
        layer.allowsEdgeAntialiasing = YES;
        layer.shouldRasterize     = NO;               // never rasterize animated content
        if (@available(iOS 13.0, *)) {
            // Hardware continuous corner curve — matches Apple's squircle and
            // costs nothing extra on the GPU compared to a circular radius.
            layer.cornerCurve = kCACornerCurveContinuous;
        }
    }
    return self;
}

- (void)setModuleCornerRadius:(CGFloat)moduleCornerRadius {
    _moduleCornerRadius = moduleCornerRadius;
    self.layer.cornerRadius = moduleCornerRadius;
}

- (void)setModuleFrame:(CGRect)frame cornerRadius:(CGFloat)radius animated:(BOOL)animated {
    frame = CGRectMake(VIPixelAlign(frame.origin.x), VIPixelAlign(frame.origin.y),
                       VIPixelAlign(frame.size.width), VIPixelAlign(frame.size.height));
    radius = MIN(radius, MIN(frame.size.width, frame.size.height) / 2.0);

    if (!animated) {
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        self.frame = frame;
        self.moduleCornerRadius = radius;
        [CATransaction commit];
        [self setNeedsLayout];
        return;
    }

    CALayer *layer = self.layer;
    CGPoint  oldPosition = layer.position;
    CGRect   oldBounds   = layer.bounds;
    CGFloat  oldRadius   = layer.cornerRadius;

    // Commit the model values first, then attach springs that animate FROM the
    // previous presentation values. This keeps the layer tree authoritative and
    // avoids the "snap back" artefact when two updates overlap.
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    self.frame = frame;
    self.moduleCornerRadius = radius;
    [CATransaction commit];

    CALayer *presentation = (CALayer *)layer.presentationLayer;
    if (presentation) {
        oldPosition = presentation.position;
        oldBounds   = presentation.bounds;
        oldRadius   = presentation.cornerRadius;
    }

    [layer addAnimation:VISpring(@"position", [NSValue valueWithCGPoint:oldPosition],
                                              [NSValue valueWithCGPoint:layer.position])
                 forKey:@"vi.position"];
    [layer addAnimation:VISpring(@"bounds", [NSValue valueWithCGRect:oldBounds],
                                            [NSValue valueWithCGRect:layer.bounds])
                 forKey:@"vi.bounds"];
    if (fabs(oldRadius - radius) > 0.01) {
        [layer addAnimation:VISpring(@"cornerRadius", @(oldRadius), @(radius))
                     forKey:@"vi.cornerRadius"];
    }

    [self setNeedsLayout];
}

@end

#pragma mark - VIIslandContainerView

@interface VIIslandContainerView ()
@property (nonatomic, strong) VIIslandModuleView *centerPill;
@property (nonatomic, strong) VIIslandModuleView *leadingBubble;
@property (nonatomic, strong) VIIslandModuleView *trailingBubble;
@property (nonatomic, strong) VIMediaView *mediaView;
@property (nonatomic, assign) VIIslandState islandState;
@property (nonatomic, assign) VIIslandGeometry geometry;
@property (nonatomic, assign) CGFloat containerWidth;
@end

@implementation VIIslandContainerView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = UIColor.clearColor;
        self.opaque = NO;
        self.clipsToBounds = NO;        // let spring overshoot render
        _islandState = VIIslandStateIdle;

        _centerPill     = [[VIIslandModuleView alloc] initWithFrame:CGRectZero];
        _leadingBubble  = [[VIIslandModuleView alloc] initWithFrame:CGRectZero];
        _trailingBubble = [[VIIslandModuleView alloc] initWithFrame:CGRectZero];

        _mediaView = [[VIMediaView alloc] initWithFrame:CGRectZero];
        _mediaView.userInteractionEnabled = NO;
        [_centerPill addSubview:_mediaView];

        for (VIIslandModuleView *module in @[ _leadingBubble, _centerPill, _trailingBubble ]) {
            [self addSubview:module];
        }

        _leadingBubble.alpha  = 0.0;
        _trailingBubble.alpha = 0.0;

        UITapGestureRecognizer *tap =
            [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(_handleTap:)];
        [_centerPill addGestureRecognizer:tap];
    }
    return self;
}

- (void)dealloc {
    // Belt and braces: the manager calls prepareForTeardown, but a stray
    // release must never leave a CADisplayLink attached to the run loop.
    [_mediaView invalidate];
}

#pragma mark - Geometry

- (void)applyGeometry:(VIIslandGeometry)geometry containerWidth:(CGFloat)width {
    self.geometry = geometry;
    self.containerWidth = width;
    [self _layoutModulesAnimated:NO];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.mediaView.frame = self.centerPill.bounds;
}

- (void)_layoutModulesAnimated:(BOOL)animated {
    VIIslandGeometry g = self.geometry;
    CGFloat width = self.containerWidth ?: CGRectGetWidth(self.bounds);
    if (width <= 0.0) return;

    BOOL satellitesVisible = (self.islandState == VIIslandStateActivity) &&
                              VIPrefs.shared.satellitesEnabled;
    BOOL expanded = (self.islandState == VIIslandStateExpanded);
    BOOL hidden   = (self.islandState == VIIslandStateHidden);

    CGFloat pillWidth  = g.width  + (expanded ? kVIExpandWidthBoost  : 0.0);
    CGFloat pillHeight = g.height + (expanded ? kVIExpandHeightBoost : 0.0);
    CGFloat pillRadius = MIN(g.cornerRadius + (expanded ? kVIExpandHeightBoost / 2.0 : 0.0),
                             pillHeight / 2.0);

    CGFloat bandCenterY = MAX(pillHeight, g.bubbleDiameter) / 2.0;
    CGFloat bubble      = g.bubbleDiameter;

    // Dynamic gap: when the pill grows, the satellites must not collide with
    // it or slide off-screen. The gap shrinks proportionally, with a 2 pt floor,
    // and the satellites are clamped inside a 6 pt screen margin.
    CGFloat totalWanted = pillWidth + 2.0 * (g.moduleGap + bubble);
    CGFloat available   = width - 12.0;
    CGFloat gap         = g.moduleGap;
    if (totalWanted > available) {
        CGFloat overflow = totalWanted - available;
        gap = MAX(2.0, g.moduleGap - overflow / 2.0);
    }

    CGFloat pillX = (width - pillWidth) / 2.0 + VIPrefs.shared.offsetX;
    CGRect pillFrame = CGRectMake(pillX, bandCenterY - pillHeight / 2.0, pillWidth, pillHeight);

    CGFloat leadingX  = CGRectGetMinX(pillFrame) - gap - bubble;
    CGFloat trailingX = CGRectGetMaxX(pillFrame) + gap;
    leadingX  = MAX(6.0, leadingX);
    trailingX = MIN(width - 6.0 - bubble, trailingX);

    CGRect leadingFrame  = CGRectMake(leadingX,  bandCenterY - bubble / 2.0, bubble, bubble);
    CGRect trailingFrame = CGRectMake(trailingX, bandCenterY - bubble / 2.0, bubble, bubble);

    // Collapsed satellites tuck *under* the pill edges and scale to zero width,
    // which reads as the Dynamic Island's "absorb" transition.
    if (!satellitesVisible) {
        leadingFrame  = CGRectMake(CGRectGetMinX(pillFrame) + 2.0, bandCenterY - 1.0, 0.0, 2.0);
        trailingFrame = CGRectMake(CGRectGetMaxX(pillFrame) - 2.0, bandCenterY - 1.0, 0.0, 2.0);
    }

    [self.centerPill     setModuleFrame:pillFrame     cornerRadius:pillRadius       animated:animated];
    [self.leadingBubble  setModuleFrame:leadingFrame  cornerRadius:bubble / 2.0     animated:animated];
    [self.trailingBubble setModuleFrame:trailingFrame cornerRadius:bubble / 2.0     animated:animated];

    void (^applyAlpha)(void) = ^{
        self.centerPill.alpha     = hidden ? 0.0 : 1.0;
        self.leadingBubble.alpha  = satellitesVisible ? 1.0 : 0.0;
        self.trailingBubble.alpha = satellitesVisible ? 1.0 : 0.0;
    };

    if (animated) {
        [UIView animateWithDuration:0.22
                              delay:0.0
                            options:UIViewAnimationOptionBeginFromCurrentState |
                                    UIViewAnimationOptionAllowUserInteraction
                         animations:applyAlpha
                         completion:nil];
    } else {
        applyAlpha();
    }

    self.mediaView.frame = self.centerPill.bounds;
    [self.mediaView setNeedsLayout];
}

#pragma mark - State

- (void)setIslandState:(VIIslandState)state animated:(BOOL)animated {
    if (_islandState == state) return;
    _islandState = state;
    self.userInteractionEnabled = (state != VIIslandStateHidden);
    [self _layoutModulesAnimated:animated];
}

- (void)_handleTap:(UITapGestureRecognizer *)tap {
    if (!VIPrefs.shared.tapToExpand) return;
    VIIslandState next = (self.islandState == VIIslandStateExpanded)
                       ? (VIPrefs.shared.satellitesEnabled ? VIIslandStateActivity : VIIslandStateIdle)
                       : VIIslandStateExpanded;
    [self setIslandState:next animated:YES];
}

#pragma mark - Preferences / media

- (void)applyPreferences {
    VIPrefs *prefs = VIPrefs.shared;

    self.mediaView.fillMode = prefs.mediaFillsPill ? VIMediaFillModeAspectFill
                                                   : VIMediaFillModeAspectFit;
    self.mediaView.frameRateCap = prefs.gifFrameRateCap;
    [self.mediaView loadMediaAtPath:prefs.mediaPath forcedKind:prefs.forcedMediaKind];

    // Satellites carry activity tint only — no media, no decode cost.
    self.leadingBubble.backgroundColor  = UIColor.blackColor;
    self.trailingBubble.backgroundColor = UIColor.blackColor;

    [self _layoutModulesAnimated:YES];
}

- (void)setPlaybackSuspended:(BOOL)playbackSuspended {
    if (_playbackSuspended == playbackSuspended) return;
    _playbackSuspended = playbackSuspended;
    self.mediaView.suspended = playbackSuspended;
}

- (void)handleMemoryPressure {
    [self.mediaView shedDecodeResources];
}

- (void)prepareForTeardown {
    [self.mediaView invalidate];
}

#pragma mark - Hit testing

- (BOOL)pointIsInsideInteractiveArea:(CGPoint)point {
    if (self.islandState == VIIslandStateHidden) return NO;

    for (VIIslandModuleView *module in @[ self.centerPill, self.leadingBubble, self.trailingBubble ]) {
        if (module.hidden || module.alpha < 0.02) continue;
        if (CGRectIsEmpty(module.frame)) continue;
        if (CGRectContainsPoint(CGRectInset(module.frame, -kVITouchSlop, -kVITouchSlop), point)) return YES;
    }
    return NO;
}

@end
