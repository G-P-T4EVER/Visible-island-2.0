//
//  VIIslandView.h
//  Three-section island container.
//
//      [ LeadingBubble ]  gap  [ ====== CenterPill ====== ]  gap  [ TrailingBubble ]
//                                     └─ hosts VIMediaView
//
//  Each module is an independent subview with its own spring animation, so a
//  satellite can appear/disappear without re-laying out the pill or restarting
//  media playback.
//

#import <UIKit/UIKit.h>
#import "Headers.h"
#import "VIPresets.h"

@class VIMediaView;

NS_ASSUME_NONNULL_BEGIN

#pragma mark - Module

/// Base module: continuous-curve rounded rect, clipped, non-opaque.
@interface VIIslandModuleView : UIView
@property (nonatomic, assign) CGFloat moduleCornerRadius;
/// Animates frame + cornerRadius with a critically-tuned CASpringAnimation.
- (void)setModuleFrame:(CGRect)frame cornerRadius:(CGFloat)radius animated:(BOOL)animated;
@end

#pragma mark - Container

@interface VIIslandContainerView : UIView

@property (nonatomic, readonly) VIIslandModuleView *centerPill;
@property (nonatomic, readonly) VIIslandModuleView *leadingBubble;
@property (nonatomic, readonly) VIIslandModuleView *trailingBubble;
@property (nonatomic, readonly) VIMediaView *mediaView;

@property (nonatomic, readonly) VIIslandState islandState;

/// Forwarded to the media engine. YES stops all decoding immediately.
@property (nonatomic, assign) BOOL playbackSuspended;

/// Applies a preset (plus the user's trims) and recomputes module frames.
- (void)applyGeometry:(VIIslandGeometry)geometry containerWidth:(CGFloat)width;

/// Re-reads VIPrefs: media path, satellite visibility, fill mode.
- (void)applyPreferences;

- (void)setIslandState:(VIIslandState)state animated:(BOOL)animated;

/// Hit-test support for VIWindow: YES only inside a visible module's rect
/// (plus a small touch-slop), so the rest of the window stays transparent.
- (BOOL)pointIsInsideInteractiveArea:(CGPoint)point;

- (void)handleMemoryPressure;

/// Stops timers/players and releases decode resources. Call before dropping.
- (void)prepareForTeardown;

@end

NS_ASSUME_NONNULL_END
